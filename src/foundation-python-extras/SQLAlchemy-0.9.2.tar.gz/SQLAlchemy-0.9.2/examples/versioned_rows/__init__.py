"""
Illustrates an extension which versions data by storing new rows for each change;
that is, what would normally be an UPDATE becomes an INSERT.

.. autosource::

"""