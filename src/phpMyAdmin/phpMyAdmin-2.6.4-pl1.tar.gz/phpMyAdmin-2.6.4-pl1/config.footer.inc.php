<?php
/**
 * In this file you may add PHP or HTML statements that will be used to define
 * the footer for phpMyAdmin pages.
 */
?>
