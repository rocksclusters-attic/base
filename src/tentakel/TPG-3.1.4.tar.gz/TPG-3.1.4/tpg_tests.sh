#!/bin/bash

python2.7 tpg_tests_py2.py && \
python2.7 tpg_tests.py && \
python3.2 tpg_tests.py
