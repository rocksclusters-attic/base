# Tamito KAJIYAMA <24 September 2001>

try:
    from japanese.c.euc_jp import *
except ImportError:
    from japanese.python.euc_jp import *
