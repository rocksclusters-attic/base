# Tamito KAJIYAMA <12 March 2000>
# $Id: __init__.py,v 1.3 2002/09/30 17:33:01 kajiyama Exp $ 

try:
    import aliases
except ImportError:
    pass
