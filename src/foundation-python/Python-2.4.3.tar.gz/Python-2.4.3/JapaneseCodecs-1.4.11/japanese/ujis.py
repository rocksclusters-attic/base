# Tamito KAJIYAMA <13 December 2000>

from japanese.euc_jp import *
