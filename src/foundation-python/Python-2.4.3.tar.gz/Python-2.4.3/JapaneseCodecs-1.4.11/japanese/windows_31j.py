# Tamito KAJIYAMA <24 September 2002>

from japanese.ms932 import *
