# Tamito KAJIYAMA <26 September 2001>

from common_iso_2022_jp_ext import test

test("japanese.c.iso-2022-jp-ext")
