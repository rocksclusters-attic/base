# Tamito KAJIYAMA <26 September 2001>

from common_shift_jis import test

test("japanese.c.shift_jis")
